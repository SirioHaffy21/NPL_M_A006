﻿using System;

namespace Net.M.A006.Exercise2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int number1st, number2nd;
            while (true)
            {
                Console.Write(" Input a 1st number: ");
                if (int.TryParse(Console.ReadLine(), out number1st))
                {
                    break;
                }

                
            }

            while (true)
            {
                Console.Write(" Input a 2nd number: ");
                if (int.TryParse(Console.ReadLine(), out number2nd))
                {
                    break;
                }

            }


            int greatestCommonDivisor = FindGreatestCommonDivisor(number1st, number2nd);

            Console.WriteLine($" The greatest common divisor of two number: {greatestCommonDivisor}");

            Console.ReadKey();
        }

        private static int FindGreatestCommonDivisor(int a, int b)
        {
            int commonDivisor = 0;

            for (int i = 1; i <= a || i <= b; i++)
            {
                if (a % i == 0 && b % i == 0) 
                {
                    commonDivisor = i;
                }
            }
            return commonDivisor;
        }
    }
}
