﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Net.M.A006.Exercise3
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[] input = { 12, 18, 24 };

            int greatestCommonDivisior = GetGreatestCommonDivisior(input);

            Console.WriteLine($"The greatest common divisior: {greatestCommonDivisior}");

            Console.ReadKey();
        }

        private static int GetGreatestCommonDivisior(int[] input)
        {

            int minium = input[0];

            for (int i = 1; i < input.Length; i++)
            {
                minium = CommonDivisior(minium, input[i]);
            }

            return minium;
        }

        private static int CommonDivisior(int x, int y)
        {
            if (x % y == 0)
            {
                return y;
            }
            return CommonDivisior(y, x % y);
        }
    }
}
