﻿using System;

namespace Net.M.A006
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            int[] input = { 5, 8, 12, -10, 6, 4 };


            int maxInput = GetMax(input);
            int minInput = GetMin(input);

            Console.Write($"Max in input: {maxInput}");
            Console.WriteLine("");
            Console.Write($"Min in input: {minInput}");

            Console.ReadKey();
        }

        private static int GetMin(int[] input)
        {

            int max = input[0];

            for (int i = 0; i < input.Length; i++)
            {
                

                if (input[i] > max) 
                {
                    max = input[i];
                }
            }

            return max;
        }

        private static int GetMax(int[] input)
        {
            int min = input[0];

            for (int i = 0; i < input.Length; i++)
            {
                

                if (min > input[i])
                {
                    min = input[i];
                }
            }

            return min;
        }
    }
}
